
import java.util.LinkedList;

/**
 * for the gui
 * @author ragostohayes
 */
public class Order_gui {
    private double totalPrice;
    private LinkedList<String> itemName;
    private LinkedList<Double> salesList;
    
    public Order_gui()
    {
        itemName = new LinkedList<>();
        salesList = new LinkedList<>();
        totalPrice = 0;
    }
            
    public void addItemName(String s)
    {
        itemName.add(s);
    }
    public void addItemPrice(Double d)
    {
        totalPrice += d;
        salesList.add(d);
    }
    public void reset() 
    {
        totalPrice = 0;
        salesList.clear();
        itemName.clear();
    }
    public String displayOrder()
    {
        return String.format("Running total:\n$%.2f",totalPrice);
        
    }
    public double getTotalPrice()
    {
        return totalPrice;
    }
}
