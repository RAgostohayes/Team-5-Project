public class Emp_System {

        private int SSN;
        private String firstName;
        private String lastName;
        private double wage;
     
    
        public Emp_System (int id, String first, String last, double salary) { 
       
            //assign variables to incoming values
        this.SSN = id;
        this.firstName = first;
        this.lastName = last;
        this.wage = salary;
      
    }
    public String getfName() {//return first name
        return firstName;
    }
    public String getlName() {//return last name
        return lastName;
    }
    public double getWage() {//return salary
        return wage;
    }
     
    public int getSSN() {//return id
        return SSN;
    }
}