import java.util.HashMap;
import java.util.Map;


public class Employees {

	private  HashMap<Integer, Emp_System> employee;//map
	
        private static final String fileName = "employees.csv";//file name
        private static final String delimiter = ",";//distinguish between values for the file
        
    
	public Employees() {
                
		employee = new HashMap<>();	//initialize
		
		
	}
	
	
	public void addEmployees (Emp_System aEmp) { //add to map with id number (SSN)
		
                int SSN = aEmp.getSSN();
                
		employee.put(SSN, aEmp);
		
                
	}
	public void removeEmployee (int SSN) { //SSN removes specific info
		employee.remove(SSN);
		
	}


	
         public HashMap<Integer, Emp_System> getEmployees()//reutrns specific info on a certain employee
    {
        return employee;
    }
         public Emp_System getID(int id)//return employee id(SSN)
    {
        return employee.get(id);
    }
        
	
	/*public String emplist () {
            
		for (Map.Entry<Integer, String> list : employee.entrySet()) {
			
                return String.format("Employee SSN: XXXXXXX%s	Employee Name: %s	Employee Salary: $%s\n",list.getKey(), list.getValue(), salary.get(list.getKey()));
		}
                
	}*/
	}
			
			
		
