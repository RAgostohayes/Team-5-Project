

/*
 * Antonio Aldaz
 * CS 234
 */
public class CreditCardPayment {
    
    private String name;
    private double totalPrice;
    private String creditCardNumber;
    private String experationDate;
           
    public void addTransaction(String name, Double totalPrice, String creditCardNumber, String experationDate)
    {
        this.name = name; 
        this.totalPrice = totalPrice;
        this.creditCardNumber = creditCardNumber;
        this.experationDate = experationDate;
    }
    public String recipt()
    {
        return String.format("Greetings %s Paid %.2f with credit card %s", name,totalPrice,creditCardNumber);
    }
}
