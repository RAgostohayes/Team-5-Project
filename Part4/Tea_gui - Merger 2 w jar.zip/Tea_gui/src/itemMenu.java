
import java.util.HashMap;
import java.util.Map;

/**
 * for the gui
 * @author ragostohayes
 */
public class itemMenu {
    
    private Map<Integer, String> menu;
    private Map<Integer, Double> pricedMenu;
    //private String itemName;
    
    //Constructor
    public itemMenu()
    {
        pricedMenu = new HashMap<>();
    	menu = new HashMap<>();
        
        menu.put(1, "Original");
    	menu.put(2, "Dragon Breath");
    	menu.put(3, "Light Flame");
    	menu.put(4, "Black Scales");
    	menu.put(5, "Plain");
    	menu.put(6, "Dragoness");
    	menu.put(7, "Herbal");
    	menu.put(8, "Sleepy Dragon");
    	menu.put(9, "Cracked Out");
    	
    	pricedMenu.put(1, 3.99);
    	pricedMenu.put(2, 4.99);
    	pricedMenu.put(3, 2.99);
    	pricedMenu.put(4, 1.99);
    	pricedMenu.put(5, 5.99);
    	pricedMenu.put(6, 6.99);
    	pricedMenu.put(7, 7.99);
    	pricedMenu.put(8, 8.99);
    	pricedMenu.put(9, 9.99);
    	    	
    }
    public String displayName(Integer i)
    {
        return menu.get(i);
    }
    public Double displayPrice(Integer i)
    {
        return pricedMenu.get(i);
    }
}
