
/**
 *
 * @author ragostohayes
 */
public class cashPayment_gui {
    private String name;
    private double totalPrice;
           
    public void addTransaction(String name, Double totalPrice)
    {
        this.name = name; 
        this.totalPrice = totalPrice;
    }
    public String recipt()
    {
        return String.format("Greetings %s Paid %.2f in cash", name,totalPrice);
    }
}
