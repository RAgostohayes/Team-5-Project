public class Inv_System {

        private int productID;
        private String productName;
        private double productQuantity;
        private double productPPU;
     
    
        public Inv_System (int id, String name, double quantity, double price) {
        
            //assign incoming variables to private instance variables
        this.productID = id;
        this.productName = name;
        this.productQuantity = quantity;
        this.productPPU = price;
      
    }
    public int getID() { //return id
        return productID;
    }
    public String getName() { //return product name
        return productName;
    }
    public double getQuantity() { //return quantity
        return productQuantity;
    }
     
    public double getPrice() { //return price per unit
        return productPPU;
    }
}