import java.util.HashMap;
import java.util.Map;


public class Inventory {

	private  HashMap<Integer, Inv_System> inventory; //map
	
        private static final String fileName = "inventory.csv"; //file name 
        private static final String delimiter = ",";
        
    
	public Inventory() {
                
		inventory = new HashMap<>();//initialize
		
		
	}
	public void addInventory (Inv_System aInv) { 
		
                int id = aInv.getID();  //Puts the Id and contents of Inv_System in a map
                
		inventory.put(id, aInv);
		
                
	}
	public void removeProduct (int ID) {
		inventory.remove(ID); //product key removes all the info
		
	}

         public HashMap<Integer, Inv_System> getInventory() //returns specific inventory
    {
        return inventory;
    }
         public Inv_System getID(int id) //gets product number
    {
        return inventory.get(id);
    }
        
	
}
			
			
		
